import { z } from "zod";

const point = z.tuple([z.number().min(0).max(1), z.number().min(0).max(1)]);
export const defaultCorners: [
  [number, number],
  [number, number],
  [number, number],
  [number, number],
] = [
  [0, 0],
  [1, 0],
  [1, 1],
  [0, 1],
];
export const classroomConfigSchema = z
  .object({
    schemaVersion: z.literal(1),
    kind: z.literal("sceneforge-classroom"),
    venueId: z.enum(["bo-live-house", "ufo-terminal"]),
    cameraId: z.string().min(1),
    screen: z
      .object({ width: z.number().min(1).max(30), height: z.number().min(1).max(12) })
      .strict(),
    mapping: z
      .object({ fit: z.enum(["contain", "cover"]), flipX: z.boolean(), flipY: z.boolean() })
      .strict(),
    projection: z
      .object({
        corners: z.tuple([point, point, point, point]),
        mode: z.enum(["grid", "content", "blackout"]),
      })
      .strict(),
    cueIndex: z.number().int().min(0).max(2),
    mediaName: z.string().max(300),
    notes: z.string().max(5000),
  })
  .strict()
  .superRefine((data, ctx) => {
    const p = data.projection.corners;
    let area = 0;
    for (let i = 0; i < 4; i++) {
      const a = p[i],
        b = p[(i + 1) % 4],
        c = p[(i + 2) % 4];
      const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
      if (cross <= 0.0001)
        ctx.addIssue({
          code: "custom",
          path: ["projection", "corners"],
          message: "Corners must be convex and ordered TL, TR, BR, BL without crossing",
        });
      area += a[0] * b[1] - b[0] * a[1];
    }
    if (area / 2 < 0.03)
      ctx.addIssue({
        code: "custom",
        path: ["projection", "corners"],
        message: "Projection area must cover at least 3% of output",
      });
    const allowed =
      data.venueId === "bo-live-house"
        ? ["front", "stage-left", "wide"]
        : ["center", "orbit", "stage"];
    if (!allowed.includes(data.cameraId))
      ctx.addIssue({
        code: "custom",
        path: ["cameraId"],
        message: `Expected one of: ${allowed.join(", ")}`,
      });
  });
export type ClassroomConfig = z.infer<typeof classroomConfigSchema>;
export function defaultClassroomConfig(): ClassroomConfig {
  return {
    schemaVersion: 1,
    kind: "sceneforge-classroom",
    venueId: "bo-live-house",
    cameraId: "front",
    screen: { width: 14, height: 7 },
    mapping: { fit: "contain", flipX: false, flipY: false },
    projection: {
      corners: defaultCorners.map((p) => [...p]) as typeof defaultCorners,
      mode: "grid",
    },
    cueIndex: 0,
    mediaName: "",
    notes: "",
  };
}
export function parseClassroomConfig(input: unknown): ClassroomConfig {
  const result = classroomConfigSchema.safeParse(input);
  if (!result.success)
    throw new Error(
      result.error.issues.map((issue) => `${issue.path.join(".")}: ${issue.message}`).join("\n"),
    );
  return result.data;
}
