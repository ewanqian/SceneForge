import { z } from "zod";
export const labConfigSchema = z
  .object({
    schemaVersion: z.literal(1),
    kind: z.literal("sceneforge-spatial-lab"),
    presetId: z.enum(["flat", "fold", "arc", "floor", "canopy", "hex", "sphere"]),
    viewId: z.enum(["center", "side", "overview"]),
    distribution: z.enum(["continuous", "repeat"]),
    fit: z.enum(["contain", "cover"]),
    paused: z.boolean(),
    gridOverlay: z.boolean(),
    sourceHint: z.string().max(300),
    goal: z.string().max(500),
    notes: z.string().max(5000),
  })
  .strict();
export type LabConfig = z.infer<typeof labConfigSchema>;
export function defaultLabConfig(): LabConfig {
  return {
    schemaVersion: 1,
    kind: "sceneforge-spatial-lab",
    presetId: "flat",
    viewId: "center",
    distribution: "continuous",
    fit: "contain",
    paused: false,
    gridOverlay: false,
    sourceHint: "内置测试图案",
    goal: "",
    notes: "",
  };
}
export function parseLabConfig(value: unknown): LabConfig {
  const result = labConfigSchema.safeParse(value);
  if (!result.success)
    throw new Error(result.error.issues.map((x) => `${x.path.join(".")}: ${x.message}`).join("\n"));
  return result.data;
}
