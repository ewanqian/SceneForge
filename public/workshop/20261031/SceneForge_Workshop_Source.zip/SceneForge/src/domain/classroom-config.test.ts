import { describe, expect, it } from "vitest";
import { projectPoint } from "../classroom/media-painter";
import { defaultClassroomConfig, parseClassroomConfig } from "./classroom-config";

describe("classroom configuration", () => {
  it("round trips a portable config without media URLs", () => {
    const config = defaultClassroomConfig();
    expect(parseClassroomConfig(JSON.parse(JSON.stringify(config)))).toEqual(config);
    expect(() => parseClassroomConfig({ ...config, videoUrl: "blob:local" })).toThrow();
  });
  it("rejects self-crossed, concave and tiny projection surfaces", () => {
    const config = defaultClassroomConfig();
    for (const corners of [
      [
        [0, 0],
        [1, 1],
        [1, 0],
        [0, 1],
      ],
      [
        [0, 0],
        [1, 0],
        [0.2, 0.1],
        [0, 1],
      ],
      [
        [0, 0],
        [0.1, 0],
        [0.1, 0.1],
        [0, 0.1],
      ],
    ]) {
      expect(() =>
        parseClassroomConfig({ ...config, projection: { ...config.projection, corners } }),
      ).toThrow("projection.corners");
    }
  });
  it("rejects a camera from another venue and non-finite sizes", () => {
    expect(() => parseClassroomConfig({ ...defaultClassroomConfig(), cameraId: "orbit" })).toThrow(
      "cameraId",
    );
    expect(() =>
      parseClassroomConfig({ ...defaultClassroomConfig(), screen: { width: NaN, height: 7 } }),
    ).toThrow("screen.width");
  });
});

describe("projection homography", () => {
  it("preserves the identity and maps all four corners of a trapezoid", () => {
    const identity = [
      [0, 0],
      [1, 0],
      [1, 1],
      [0, 1],
    ];
    expect(projectPoint(0.3, 0.7, identity)).toEqual([0.3, 0.7]);
    const target = [
      [0.2, 0.1],
      [0.8, 0.2],
      [1, 0.9],
      [0, 1],
    ];
    for (const [i, uv] of identity.entries()) {
      const value = projectPoint(uv[0], uv[1], target);
      expect(value[0]).toBeCloseTo(target[i][0]);
      expect(value[1]).toBeCloseTo(target[i][1]);
    }
  });
});
