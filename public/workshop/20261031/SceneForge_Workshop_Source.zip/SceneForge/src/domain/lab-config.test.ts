import { describe, expect, it } from "vitest";
import { defaultLabConfig, parseLabConfig } from "./lab-config";

describe("portable spatial lab configuration", () => {
  it("round trips all screen layouts and preserves the learner's question", () => {
    for (const presetId of ["flat", "fold", "arc", "floor", "canopy", "hex", "sphere"] as const) {
      const value = {
        ...defaultLabConfig(),
        presetId,
        goal: "Can I read the subject from the side?",
      };
      expect(parseLabConfig(JSON.parse(JSON.stringify(value)))).toEqual(value);
    }
  });
  it("rejects unknown versions, layouts and runtime media objects", () => {
    const value = defaultLabConfig();
    expect(() => parseLabConfig({ ...value, schemaVersion: 2 })).toThrow("schemaVersion");
    expect(() => parseLabConfig({ ...value, presetId: "all-projectors" })).toThrow("presetId");
    expect(() => parseLabConfig({ ...value, stream: {}, videoUrl: "blob:temporary" })).toThrow();
  });
  it("limits imported reflection notes instead of accepting unlimited payloads", () => {
    expect(() => parseLabConfig({ ...defaultLabConfig(), notes: "x".repeat(5001) })).toThrow(
      "notes",
    );
  });
});
