import { AdaptiveDpr, OrbitControls, Preload } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { createXRStore, XR } from "@react-three/xr";
import { Component, type PropsWithChildren, Suspense } from "react";
import type { CameraPreset, VenueManifest, ViewerState } from "../domain/scene";
import { CameraRig } from "./CameraRig";
import { VenueScene } from "./VenueScene";

export const xrStore = createXRStore();

function ViewportUnavailable() {
  return (
    <div role="alert" style={{ padding: 32, color: "#f2d098", lineHeight: 1.7 }}>
      3D 画面未能启动。请开启浏览器硬件加速，或换用新版桌面浏览器。
      <br />
      参数面板、JSON 保存与独立 2D 投影窗口仍可使用。课堂可改用已保存截图进行观察。
    </div>
  );
}
class ViewportBoundary extends Component<PropsWithChildren, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? <ViewportUnavailable /> : this.props.children;
  }
}

interface StageCanvasProps {
  venue: VenueManifest;
  cameraPreset: CameraPreset;
  viewerState: ViewerState;
  videoUrl?: string;
  screenCanvas?: HTMLCanvasElement;
}

export function StageCanvas({
  venue,
  cameraPreset,
  viewerState,
  videoUrl,
  screenCanvas,
}: StageCanvasProps) {
  return (
    <ViewportBoundary>
      <Canvas
        fallback={<ViewportUnavailable />}
        shadows
        dpr={[1, 1.75]}
        camera={{ position: cameraPreset.position, fov: 54, near: 0.08, far: 180 }}
        gl={{ antialias: true, powerPreference: "high-performance" }}
      >
        <XR store={xrStore}>
          <Suspense fallback={null}>
            <CameraRig preset={cameraPreset} />
            <VenueScene
              venue={venue}
              viewerState={viewerState}
              videoUrl={videoUrl}
              screenCanvas={screenCanvas}
            />
            <OrbitControls
              makeDefault
              target={cameraPreset.target}
              minDistance={2}
              maxDistance={70}
              maxPolarAngle={Math.PI * 0.49}
            />
            <AdaptiveDpr pixelated />
            <Preload all />
          </Suspense>
        </XR>
      </Canvas>
    </ViewportBoundary>
  );
}
