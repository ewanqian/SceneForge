import { useFrame } from "@react-three/fiber";
import { useEffect, useMemo } from "react";
import * as THREE from "three";

interface ScreenSurfaceProps {
  color: string;
  emissiveIntensity: number;
  videoUrl?: string;
  screenCanvas?: HTMLCanvasElement;
  side?: THREE.Side;
}

export function ScreenSurface({
  color,
  emissiveIntensity,
  videoUrl,
  screenCanvas,
  side,
}: ScreenSurfaceProps) {
  const video = useMemo(() => {
    if (!videoUrl) return undefined;

    const element = document.createElement("video");
    element.src = videoUrl;
    element.loop = true;
    element.muted = true;
    element.playsInline = true;
    element.crossOrigin = "anonymous";
    return element;
  }, [videoUrl]);

  const texture = useMemo(() => {
    if (!video) return undefined;
    const nextTexture = new THREE.VideoTexture(video);
    nextTexture.colorSpace = THREE.SRGBColorSpace;
    nextTexture.minFilter = THREE.LinearFilter;
    nextTexture.magFilter = THREE.LinearFilter;
    return nextTexture;
  }, [video]);

  useEffect(() => {
    if (!video) return;
    void video.play().catch(() => undefined);
    return () => {
      video.pause();
      video.removeAttribute("src");
      video.load();
    };
  }, [video]);

  useEffect(() => () => texture?.dispose(), [texture]);

  const canvasTexture = useMemo(() => {
    if (!screenCanvas) return undefined;
    const t = new THREE.CanvasTexture(screenCanvas);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [screenCanvas]);
  useFrame(() => {
    if (canvasTexture) canvasTexture.needsUpdate = true;
  });
  useEffect(() => () => canvasTexture?.dispose(), [canvasTexture]);

  return (
    <meshStandardMaterial
      color={videoUrl || screenCanvas ? "#ffffff" : color}
      emissive={videoUrl || screenCanvas ? "#ffffff" : color}
      emissiveIntensity={emissiveIntensity}
      map={canvasTexture ?? texture}
      emissiveMap={canvasTexture ?? texture}
      roughness={0.34}
      toneMapped={!videoUrl && !screenCanvas}
      side={side}
    />
  );
}
