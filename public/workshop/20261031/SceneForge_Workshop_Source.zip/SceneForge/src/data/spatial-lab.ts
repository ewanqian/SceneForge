export const labPresets = [
  {
    id: "flat",
    number: "01",
    title: "单面主屏",
    en: "FLAT SCREEN",
    shape: "plane",
    width: 8,
    height: 4.5,
    summary: "一块 16:9 主屏。先看完整画面，再检查人物遮挡。",
    dimension: "8 × 4.5 m · 教学假设",
    question: "主体进入空间后，仍然看得清吗？",
    steps: [
      "选一段自己的短视频，先用完整显示。",
      "比较中心和侧面，记录主体与人物的关系。",
      "切换填满裁切，检查是否丢失关键信息。",
    ],
    takeaway: "屏幕比例相同，观看位置仍然改变体验。",
  },
  {
    id: "fold",
    number: "02",
    title: "L 形双折屏",
    en: "FOLDED SURFACES",
    shape: "fold",
    width: 10,
    height: 4.5,
    summary: "两块 5 × 4.5 m 屏幕相接。比较一个画面跨屏与每屏各播一遍。",
    dimension: "两块 5 × 4.5 m · 90° 转角",
    question: "同一个动作跨过转角，会发生什么？",
    steps: [
      "选择连续跨屏，让一幅画面分到两块屏幕。",
      "换到侧面，观察接缝、运动方向与主体位置。",
      "改成每屏重复，同一机位比较节奏与信息量。",
    ],
    takeaway: "内容连续不等于观众从任何位置都能读到连续动作。",
  },
  {
    id: "arc",
    number: "03",
    title: "180° 弧形环幕",
    en: "PANORAMIC SURFACE",
    shape: "arc",
    width: Math.PI * 5,
    height: 4.5,
    summary: "半径 5 m 的半圆环幕。普通宽幅画面沿弧长展开。",
    dimension: "半径 5 m · 弧长约 15.7 m · 高 4.5 m",
    question: "画面铺开之后，注意力落在哪里？",
    steps: [
      "先看测试图案的编号，辨认左右边缘。",
      "导入视频，对比完整显示与填满裁切。",
      "从中心换到侧面，检查边缘信息是否仍重要。",
    ],
    takeaway: "弧形环幕描述屏幕形状。它不自动把普通视频变成 360° 内容。",
  },
  {
    id: "floor", number: "04", title: "地面＋正面折屏", en: "FLOOR / FRONT",
    shape: "floor", width: 8, height: 10.5,
    summary: "8 m宽主屏接6 m深地屏，保持几何不动，用同一画布的上下区域连接两面。",
    dimension: "正面8 × 4.5 m / 地面8 × 6 m · 教学假设",
    question: "画面走到地面后，从人眼高度还能读清吗？",
    steps: ["用编号网格辨认正面与地面的分界。", "切换侧面与总览，观察透视压缩。", "比较连续跨屏与每屏重复，选择适合自己内容的方式。"],
    takeaway: "展开图连续，不代表地面的图像从观众位置看仍是原比例。",
  },
  {
    id: "canopy", number: "05", title: "主屏＋顶屏", en: "FRONT / CANOPY",
    shape: "canopy", width: 8, height: 10.5,
    summary: "正面主屏与水平顶屏相接。用连续画布观察画面从头顶进入主屏的路径。",
    dimension: "正面8 × 4.5 m / 顶屏8 × 6 m · 高4.9 m",
    question: "同一条运动如何从头顶接到正面？",
    steps: ["先用总览辨认主屏和顶屏的接边。", "切到人眼高度，观察顶屏的信息还剩多少。", "用自己的内容尝试连续分配，再比较每屏重复。"],
    takeaway: "顶屏的观看角度与主屏不同，不能只在展开图里判断衔接。",
  },
  {
    id: "hex", number: "06", title: "六边形悬屏", en: "HEXAGON / SIX SCREENS",
    shape: "hex", width: 6 * 8 * Math.tan(Math.PI / 6), height: 3.5,
    summary: "六块平面围成悬空六边形。不是一块六边形平板；画布依次分成六段。",
    dimension: "6块约4.62 × 3.5 m / 内切半径4 m / 离地1 m",
    question: "围绕观众的信息，应该连续流动还是分别重复？",
    steps: ["从总览看清六块屏的顺序。", "切换中心和侧面，观察哪块屏被遮住。", "比较六段连续内容与每屏完整重复。"],
    takeaway: "六屏展开带有一个首尾接缝；空间包围不等于所有人能同时看见全部信息。",
  },
  {
    id: "sphere",
    number: "07",
    title: "360° 媒体球",
    en: "EQUIRECTANGULAR MEDIA",
    shape: "sphere",
    width: 2,
    height: 1,
    summary: "把 2:1 等距柱状画面映射到球内。用于辨认 360° 媒体的投影关系。",
    dimension: "2:1 等距柱状媒体 · 球内观看示意",
    question: "这是宽画面，还是包含四周方向的内容？",
    steps: [
      "观察球内网格。拖动画面改变观看方向。",
      "选真正的 2:1 等距柱状素材；比例相同也需核实编码语义。",
      "与弧形环幕对照，说明屏幕几何与媒体格式的区别。",
    ],
    takeaway: "普通 16:9 视频贴到球内会拉伸，不能据此称为 360° 作品。",
  },
] as const;
export type LabPresetId = (typeof labPresets)[number]["id"];
export const labViews = [
  { id: "center", label: "中心观看" },
  { id: "side", label: "侧面观看" },
  { id: "overview", label: "空间总览" },
] as const;

export type LabPanel = {
  position: [number, number, number];
  rotation: [number, number, number];
  size: [number, number];
  uv: [number, number, number, number];
};
// Geometry belongs to the venue preset; runtime config controls media, not screen movement.
export function labPanels(id: string): LabPanel[] {
  if (id === "fold") return [
    { position: [-2.5, 2.65, -2.5], rotation: [0, 0, 0], size: [5, 4.5], uv: [0, 0, .5, 1] },
    { position: [0, 2.65, 0], rotation: [0, -Math.PI / 2, 0], size: [5, 4.5], uv: [.5, 0, .5, 1] },
  ];
  if (id === "floor") return [
    { position: [0, 2.65, -3], rotation: [0, 0, 0], size: [8, 4.5], uv: [0, 6 / 10.5, 1, 4.5 / 10.5] },
    { position: [0, .4, 0], rotation: [-Math.PI / 2, 0, 0], size: [8, 6], uv: [0, 0, 1, 6 / 10.5] },
  ];
  if (id === "canopy") return [
    { position: [0, 2.65, -3], rotation: [0, 0, 0], size: [8, 4.5], uv: [0, 0, 1, 4.5 / 10.5] },
    { position: [0, 4.9, 0], rotation: [Math.PI / 2, 0, 0], size: [8, 6], uv: [0, 4.5 / 10.5, 1, 6 / 10.5] },
  ];
  if (id === "hex") return Array.from({ length: 6 }, (_, i) => {
    const a = i * Math.PI / 3;
    return { position: [4 * Math.sin(a), 2.75, -4 * Math.cos(a)], rotation: [0, -a, 0], size: [8 * Math.tan(Math.PI / 6), 3.5], uv: [i / 6, 0, 1 / 6, 1] };
  });
  return [{ position: [0, 2.65, -2.5], rotation: [0, 0, 0], size: [8, 4.5], uv: [0, 0, 1, 1] }];
}
export function labContentRatio(id: string, distribution: string): number {
  const preset = labPresets.find(p => p.id === id) ?? labPresets[0];
  if (distribution === "repeat" && ["fold", "floor", "canopy", "hex"].includes(id)) {
    const panel = labPanels(id)[0];
    return panel.size[0] / panel.size[1];
  }
  return preset.width / preset.height;
}
