import { describe, expect, it } from "vitest";
import { labContentRatio, labPanels } from "./spatial-lab";

describe("fixed multi-screen atlas", () => {
  it("assigns six equal non-overlapping strips around the hexagon", () => {
    const panels = labPanels("hex");
    expect(panels).toHaveLength(6);
    panels.forEach((p, i) => {
      expect(p.uv[0]).toBeCloseTo(i / 6);
      expect(p.uv[2]).toBeCloseTo(1 / 6);
      const next = panels[(i + 1) % panels.length];
      const right = [p.position[0] + p.size[0] / 2 * Math.cos(p.rotation[1]), p.position[2] - p.size[0] / 2 * Math.sin(p.rotation[1])];
      const left = [next.position[0] - next.size[0] / 2 * Math.cos(next.rotation[1]), next.position[2] + next.size[0] / 2 * Math.sin(next.rotation[1])];
      expect(right[0]).toBeCloseTo(left[0]);
      expect(right[1]).toBeCloseTo(left[1]);
    });
  });
  it("joins the vertical atlas at the actual floor/front and front/canopy edges", () => {
    for (const id of ["floor", "canopy"]) {
      const [front, horizontal] = labPanels(id);
      expect(horizontal.position[1]).toBeCloseTo(id === "floor" ? front.position[1] - front.size[1] / 2 : front.position[1] + front.size[1] / 2);
      expect(front.uv[3] + horizontal.uv[3]).toBeCloseTo(1);
      expect(id === "floor" ? front.uv[1] : front.uv[1] + front.uv[3]).toBeCloseTo(id === "floor" ? horizontal.uv[1] + horizontal.uv[3] : horizontal.uv[1]);
      expect(labContentRatio(id, "continuous")).toBeCloseTo(8 / 10.5);
      expect(labContentRatio(id, "repeat")).toBeCloseTo(8 / 4.5);
    }
  });
});
