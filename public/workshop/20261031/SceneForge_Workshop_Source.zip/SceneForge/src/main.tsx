import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
import { ClassroomApp, ProjectionOutput } from "./classroom/ClassroomApp";
import { LabApp } from "./lab/LabApp";
import "./styles.css";

const root = document.getElementById("root");

if (!root) {
  throw new Error("SceneForge could not find the #root element.");
}

createRoot(root).render(
  <StrictMode>
    {new URLSearchParams(location.search).has("lab") ? (
      <LabApp />
    ) : new URLSearchParams(location.search).has("output") ? (
      <ProjectionOutput />
    ) : new URLSearchParams(location.search).has("classroom") ? (
      <ClassroomApp />
    ) : (
      <App />
    )}
  </StrictMode>,
);
