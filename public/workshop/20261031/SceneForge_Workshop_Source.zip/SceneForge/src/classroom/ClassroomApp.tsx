import { useEffect, useMemo, useRef, useState } from "react";
import { StageCanvas } from "../components/StageCanvas";
import { venues } from "../data/venues";
import {
  type ClassroomConfig,
  defaultClassroomConfig,
  defaultCorners,
  parseClassroomConfig,
} from "../domain/classroom-config";
import { applyCue } from "../domain/cue-engine";
import { initialViewerState } from "../domain/scene";
import { paintMedia, paintProjection } from "./media-painter";
import "./classroom.css";

const KEY = "sceneforge-classroom-v1",
  CHANNEL = "sceneforge-classroom-v1";
interface WireState {
  config: ClassroomConfig;
  videoUrl?: string;
  playing: boolean;
  elapsed: number;
}
interface AgentApi {
  getState(): ClassroomConfig;
  setState(input: unknown): ClassroomConfig;
  reset(): ClassroomConfig;
}
declare global {
  interface Window {
    sceneForgeClassroom?: AgentApi;
  }
}
function saveFile(data: unknown, name: string) {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }),
  );
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function usePainter(
  config: ClassroomConfig,
  videoUrl: string | undefined,
  playing: boolean,
  elapsed: number,
  onError: (text: string) => void,
  grid = false,
) {
  const canvas = useMemo(
    () => Object.assign(document.createElement("canvas"), { width: 960, height: 540 }),
    [],
  );
  const live = useRef({ config, playing, elapsed, grid });
  live.current = { config, playing, elapsed, grid };
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const errorRef = useRef(onError);
  errorRef.current = onError;
  useEffect(() => {
    errorRef.current("");
    if (!videoUrl) {
      videoRef.current = null;
      return;
    }
    const video = document.createElement("video");
    video.src = videoUrl;
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    videoRef.current = video;
    video.onerror = () => errorRef.current("视频无法解码。请换 H.264 MP4，或切回测试图案。");
    video.onloadedmetadata = () => {
      video.currentTime = live.current.elapsed % (video.duration || 1);
      if (live.current.playing)
        void video.play().catch(() => errorRef.current("视频未自动播放。请点击播放重试。"));
    };
    return () => {
      video.pause();
      video.removeAttribute("src");
      video.load();
      if (videoRef.current === video) videoRef.current = null;
    };
  }, [videoUrl]);
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (playing)
      void video.play().catch(() => errorRef.current("视频播放被浏览器阻止。请点击播放重试。"));
    else video.pause();
  }, [playing]);
  useEffect(() => {
    const video = videoRef.current;
    if (video?.readyState && Number.isFinite(video.duration))
      video.currentTime = elapsed % video.duration;
  }, [elapsed]);
  const clock = useRef(elapsed);
  useEffect(() => {
    clock.current = elapsed;
  }, [elapsed]);
  useEffect(() => {
    let frame = 0;
    let last = performance.now();
    const draw = () => {
      const now = performance.now();
      const value = live.current;
      if (value.playing) clock.current += Math.min(0.1, (now - last) / 1000);
      last = now;
      const height = Math.round(
        (canvas.width * value.config.screen.height) / value.config.screen.width,
      );
      if (canvas.height !== height) canvas.height = height;
      paintMedia(canvas, value.config, videoRef.current, clock.current, value.grid);
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, [canvas]);
  return canvas;
}

export function ClassroomApp() {
  const [config, setConfig] = useState(() => {
    try {
      const saved = localStorage.getItem(KEY);
      return saved ? parseClassroomConfig(JSON.parse(saved)) : defaultClassroomConfig();
    } catch {
      return defaultClassroomConfig();
    }
  });
  const [message, setMessage] = useState(
    "参数需导出为 JSON 才算保存到磁盘。默认测试图案可离线运行。",
  );
  const reportError = (text: string) => {
    if (text) setMessage(text);
  };
  const [videoUrl, setVideoUrl] = useState<string>();
  const [playing, setPlaying] = useState(true);
  const [elapsed, setElapsed] = useState(0);
  const [autoCue, setAutoCue] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const channel = useRef<BroadcastChannel | null>(null);
  const output = useRef<Window | null>(null);
  const urls = useRef<string[]>([]);
  const live = useRef<WireState>({ config, videoUrl, playing, elapsed });
  live.current = { config, videoUrl, playing, elapsed };
  const source = usePainter(config, videoUrl, playing, elapsed, reportError);
  const baseVenue = venues.find((v) => v.id === config.venueId) ?? venues[0];
  const venue = useMemo(
    () => ({ ...baseVenue, screen: { ...baseVenue.screen, ...config.screen } }),
    [baseVenue, config.screen],
  );
  const camera = venue.cameras.find((c) => c.id === config.cameraId) ?? venue.cameras[0];
  const viewer = useMemo(
    () => applyCue({ ...initialViewerState, reflections: false }, venue.cues[config.cueIndex]),
    [venue.cues, config.cueIndex],
  );
  const preview = useRef<HTMLCanvasElement>(null);
  const commit = (input: unknown) => {
    const next = parseClassroomConfig(input);
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* File export remains available. */
    }
    setConfig(next);
    return next;
  };
  const patch = (part: Partial<ClassroomConfig>) => {
    try {
      commit({ ...config, ...part });
    } catch (error) {
      setMessage(String(error));
    }
  };
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(config));
    } catch {
      /* JSON export remains available. */
    }
    channel.current?.postMessage({ type: "state", config, videoUrl, playing, elapsed });
  }, [config, videoUrl, playing, elapsed]);
  useEffect(() => {
    if (!("BroadcastChannel" in window)) {
      setMessage("浏览器不支持本机输出同步，请换新版桌面浏览器。");
      return;
    }
    const next = new BroadcastChannel(CHANNEL);
    channel.current = next;
    next.onmessage = (event) => {
      if (event.data?.type === "ready") next.postMessage({ type: "state", ...live.current });
    };
    return () => {
      next.close();
      channel.current = null;
    };
  }, []);
  useEffect(() => {
    const timer = setInterval(() => {
      if (!playing) return;
      setSeconds((current) => {
        const next = (current + 0.25) % 30;
        if (autoCue) setConfig((c) => ({ ...c, cueIndex: Math.floor(next / 10) }));
        return next;
      });
    }, 250);
    return () => clearInterval(timer);
  }, [playing, autoCue]);
  useEffect(() => {
    let frame = 0;
    const render = () => {
      const canvas = preview.current,
        ctx = canvas?.getContext("2d");
      if (canvas && ctx) ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
      frame = requestAnimationFrame(render);
    };
    frame = requestAnimationFrame(render);
    return () => cancelAnimationFrame(frame);
  }, [source]);
  useEffect(() => {
    const api: AgentApi = {
      getState: () => structuredClone(live.current.config),
      setState: (input) => {
        const next = parseClassroomConfig(input);
        try {
          localStorage.setItem(KEY, JSON.stringify(next));
        } catch {
          /* File export remains available. */
        }
        const mediaChanged = next.mediaName !== live.current.config.mediaName;
        if (mediaChanged) setVideoUrl(undefined);
        live.current = {
          ...live.current,
          config: next,
          videoUrl: mediaChanged ? undefined : live.current.videoUrl,
        };
        setConfig(next);
        return structuredClone(next);
      },
      reset: () => {
        const next = defaultClassroomConfig();
        setVideoUrl(undefined);
        try {
          localStorage.setItem(KEY, JSON.stringify(next));
        } catch {
          /* File export remains available. */
        }
        live.current = { ...live.current, config: next, videoUrl: undefined };
        setConfig(next);
        return structuredClone(next);
      },
    };
    window.sceneForgeClassroom = api;
    return () => {
      if (window.sceneForgeClassroom === api) delete window.sceneForgeClassroom;
    };
  }, []);
  useEffect(
    () => () => {
      for (const url of urls.current) URL.revokeObjectURL(url);
    },
    [],
  );
  function openOutput() {
    const url = new URL(window.location.href);
    url.search = "?output=1";
    output.current = window.open(url, "sceneforge-projector", "popup,width=1280,height=720");
    setMessage(
      output.current
        ? "投影窗口已打开。拖至投影屏，双击画面全屏；Esc 退出。只在本机同源页面间同步。"
        : "输出窗口被浏览器拦截。请允许此站弹窗后重试。",
    );
  }
  function snapshot(label: string) {
    try {
      localStorage.setItem(`${KEY}-${label}`, JSON.stringify(config));
    } catch {}
    saveFile(config, `SceneForge-${label}.json`);
    setMessage(`${label} JSON 已下载。视频需另存原文件。`);
  }
  function restore(label: string) {
    try {
      const value = localStorage.getItem(`${KEY}-${label}`);
      if (!value) throw new Error(`尚未保存 ${label}`);
      const next = commit(JSON.parse(value));
      setVideoUrl(undefined);
      if (next.mediaName)
        setMessage(`已恢复 ${label}。视频不在 JSON 内，请重新选 ${next.mediaName}。`);
    } catch (error) {
      setMessage(String(error));
    }
  }
  return (
    <main className="classroom-shell">
      <header className="classroom-header">
        <div>
          <p className="eyebrow">SCENEFORGE / CLASSROOM V1</p>
          <h1>舞台复刻工具包</h1>
          <p>3D 屏幕贴图预演与单台投影四角校准。教学场景为示意模型，单位米、右手系、Y 向上。</p>
        </div>
        <a href="?">原版场景浏览</a>
      </header>
      <div className="classroom-body">
        <aside className="classroom-controls">
          <section>
            <h2>01 空间与观看</h2>
            <label>
              场景
              <select
                value={config.venueId}
                onChange={(e) => {
                  const v = venues.find((v) => v.id === e.target.value);
                  if (v)
                    patch({
                      venueId: v.id as ClassroomConfig["venueId"],
                      cameraId: v.cameras[0].id,
                      screen: { width: v.screen.width, height: v.screen.height },
                    });
                }}
              >
                {venues.map((v) => (
                  <option value={v.id} key={v.id}>
                    {v.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              观看位置
              <select value={config.cameraId} onChange={(e) => patch({ cameraId: e.target.value })}>
                {venue.cameras.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </label>
            <div className="classroom-pair">
              {(["width", "height"] as const).map((k) => (
                <label key={k}>
                  主屏{k === "width" ? "宽" : "高"} / m
                  <input
                    type="number"
                    min="1"
                    max={k === "width" ? 30 : 12}
                    step="0.1"
                    value={config.screen[k]}
                    onChange={(e) =>
                      patch({ screen: { ...config.screen, [k]: Number(e.target.value) } })
                    }
                  />
                </label>
              ))}
            </div>
            <small>宽高为练习参数。修改后换到侧面和远景检查遮挡。</small>
          </section>
          <section>
            <h2>02 Mapping 映射</h2>
            <label>
              本地视频
              <input
                type="file"
                accept="video/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const url = URL.createObjectURL(file);
                  urls.current.push(url);
                  setVideoUrl(url);
                  patch({ mediaName: file.name });
                  setMessage(`已选择 ${file.name}。文件留在本机，不上传。`);
                }}
              />
            </label>
            <p className="classroom-file">
              {config.mediaName
                ? `${videoUrl ? "已载入" : "待重新选取"}：${config.mediaName}`
                : "内置原创测试图案"}
            </p>
            <button
              type="button"
              onClick={() => {
                setVideoUrl(undefined);
                patch({ mediaName: "" });
              }}
            >
              使用测试图案
            </button>
            <label>
              画面比例
              <select
                value={config.mapping.fit}
                onChange={(e) =>
                  patch({
                    mapping: { ...config.mapping, fit: e.target.value as "contain" | "cover" },
                  })
                }
              >
                <option value="contain">完整显示 contain</option>
                <option value="cover">填满裁切 cover</option>
              </select>
            </label>
            {(["flipX", "flipY"] as const).map((k) => (
              <label className="classroom-check" key={k}>
                <input
                  type="checkbox"
                  checked={config.mapping[k]}
                  onChange={(e) => patch({ mapping: { ...config.mapping, [k]: e.target.checked } })}
                />
                {k === "flipX" ? "左右翻转" : "上下翻转"}
              </label>
            ))}
            <small>此处改变视频到 3D 屏幕的 UV 内容。投影仪几何校准在下一节。</small>
          </section>
          <section>
            <h2>03 Cue 与播放</h2>
            <div className="classroom-actions">
              {venue.cues.map((cue, i) => (
                <button
                  type="button"
                  aria-pressed={config.cueIndex === i}
                  key={cue.id}
                  onClick={() => {
                    setAutoCue(false);
                    patch({ cueIndex: i });
                  }}
                >
                  {cue.name}
                </button>
              ))}
            </div>
            <div className="classroom-actions">
              <button type="button" onClick={() => setPlaying((p) => !p)}>
                {playing ? "暂停" : "播放 / 重试"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setElapsed((t) => t + 0.0001);
                  setSeconds(0);
                  patch({ cueIndex: 0 });
                }}
              >
                从头重播
              </button>
            </div>
            <label className="classroom-check">
              <input
                type="checkbox"
                checked={autoCue}
                onChange={(e) => setAutoCue(e.target.checked)}
              />
              每 10 秒自动切 Cue（30 秒循环）
            </label>
            <output>{seconds.toFixed(1)} / 30s</output>
            <small>Cue 改场景灯光与测试图案。视频仍为同一文件，不提供帧级同步。</small>
          </section>
          <section>
            <h2>04 投影输出</h2>
            <button type="button" className="primary-action" onClick={openOutput}>
              打开独立投影窗口
            </button>
            <label>
              输出模式
              <select
                value={config.projection.mode}
                onChange={(e) =>
                  patch({
                    projection: {
                      ...config.projection,
                      mode: e.target.value as ClassroomConfig["projection"]["mode"],
                    },
                  })
                }
              >
                <option value="grid">校准网格</option>
                <option value="content">内容输出</option>
                <option value="blackout">黑屏</option>
              </select>
            </label>
            <div className="classroom-actions">
              <button
                type="button"
                onClick={() => patch({ projection: { ...config.projection, mode: "blackout" } })}
              >
                立即黑屏
              </button>
              <button
                type="button"
                onClick={() =>
                  patch({
                    projection: { ...config.projection, corners: structuredClone(defaultCorners) },
                  })
                }
              >
                复位四角
              </button>
            </div>
            <fieldset>
              <legend>四角坐标（0–1；左上起顺时针）</legend>
              {config.projection.corners.map((p, i) => (
                <div className="classroom-corner" key={["TL", "TR", "BR", "BL"][i]}>
                  <span>{["TL", "TR", "BR", "BL"][i]}</span>
                  {p.map((value, axis) => (
                    <label key={axis === 0 ? "x" : "y"}>
                      {axis === 0 ? "X" : "Y"}
                      <input
                        aria-label={`${["TL", "TR", "BR", "BL"][i]} ${axis === 0 ? "X" : "Y"}`}
                        type="number"
                        min="0"
                        max="1"
                        step="0.01"
                        value={value}
                        onChange={(e) => {
                          const corners = structuredClone(config.projection.corners);
                          corners[i][axis] = Number(e.target.value);
                          patch({ projection: { ...config.projection, corners } });
                        }}
                      />
                    </label>
                  ))}
                </div>
              ))}
            </fieldset>
            <small>
              仅单一平面、单投影仪的四角校准。没有曲面、多机融合、亮度标定或实际投影硬件验证。
            </small>
          </section>
          <section>
            <h2>05 保存与复查</h2>
            <div className="classroom-actions">
              <button type="button" onClick={() => snapshot("V1")}>
                存 V1
              </button>
              <button type="button" onClick={() => snapshot("V2")}>
                存 V2
              </button>
              <button type="button" onClick={() => restore("V1")}>
                看 V1
              </button>
              <button type="button" onClick={() => restore("V2")}>
                看 V2
              </button>
            </div>
            <label>
              导入参数 JSON
              <input
                type="file"
                accept=".json,application/json"
                onChange={async (e) => {
                  try {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    if (file.size > 100000) throw new Error("参数文件过大，限 100KB");
                    const next = commit(JSON.parse(await file.text()));
                    setVideoUrl(undefined);
                    setMessage(
                      next.mediaName
                        ? `参数已导入，请重新选择原视频 ${next.mediaName}`
                        : "参数已导入。",
                    );
                  } catch (error) {
                    setMessage(`未导入，保留当前场景。${String(error)}`);
                  }
                }}
              />
            </label>
            <label>
              问题、机位与修改理由
              <textarea
                value={config.notes}
                maxLength={5000}
                onChange={(e) => patch({ notes: e.target.value })}
              />
            </label>
            <button type="button" onClick={() => saveFile(config, "SceneForge-classroom.json")}>
              导出完整参数与笔记
            </button>
            <small>JSON 不包含视频与模型。换电脑请同时复制原素材。浏览器缓存不代替磁盘备份。</small>
          </section>
        </aside>
        <section className="classroom-view">
          <div className="classroom-stage">
            <StageCanvas
              venue={venue}
              cameraPreset={camera}
              viewerState={viewer}
              screenCanvas={source}
            />
          </div>
          <div className="classroom-summary">
            <p role="status">{message}</p>
            <canvas ref={preview} width={384} height={216} aria-label="映射内容预览" />
            <p>
              观看任务：同一个机位、同一个段落，对比 V1 与 V2。
              <br />
              Agent 入口：window.sceneForgeClassroom；配置契约见随包说明。
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}

export function ProjectionOutput() {
  const [wire, setWire] = useState<WireState>({
    config: defaultClassroomConfig(),
    playing: true,
    elapsed: 0,
  });
  const [error, setError] = useState("");
  const [ready, setReady] = useState(false);
  const canvas = useRef<HTMLCanvasElement>(null);
  const latest = useRef(wire);
  latest.current = wire;
  const source = usePainter(
    wire.config,
    wire.videoUrl,
    wire.playing,
    wire.elapsed,
    setError,
    wire.config.projection.mode === "grid",
  );
  useEffect(() => {
    if (!("BroadcastChannel" in window)) {
      setError("浏览器不支持本机输出同步。请换新版桌面浏览器。");
      return;
    }
    const channel = new BroadcastChannel(CHANNEL);
    channel.onmessage = (e) => {
      if (e.data?.type !== "state") return;
      try {
        const config = parseClassroomConfig(e.data.config);
        setWire({
          config,
          videoUrl:
            typeof e.data.videoUrl === "string" && e.data.videoUrl.startsWith("blob:")
              ? e.data.videoUrl
              : undefined,
          playing: Boolean(e.data.playing),
          elapsed: Number.isFinite(e.data.elapsed) ? e.data.elapsed : 0,
        });
        setReady(true);
      } catch {
        setError("控制端参数无效，未应用。");
      }
    };
    channel.postMessage({ type: "ready" });
    const timer = setInterval(() => channel.postMessage({ type: "ready" }), 2000);
    return () => {
      clearInterval(timer);
      channel.close();
    };
  }, []);
  useEffect(() => {
    let frame = 0;
    const draw = () => {
      const target = canvas.current;
      if (target) {
        if (target.width !== innerWidth || target.height !== innerHeight) {
          target.width = innerWidth;
          target.height = innerHeight;
        }
        paintProjection(target, source, latest.current.config);
      }
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, [source]);
  return (
    <main className="projection-output">
      <canvas
        ref={canvas}
        aria-label="投影输出画面"
        onDoubleClick={() => {
          void document.documentElement
            .requestFullscreen()
            .catch(() => setError("全屏失败。请使用浏览器全屏菜单。"));
        }}
      />
      {wire.config.projection.mode !== "blackout" && (!ready || error) && (
        <p className="projection-error" role="status">
          {error || "等待控制端。请在同一浏览器打开 ?classroom=1。"}
        </p>
      )}
    </main>
  );
}
