import type { ClassroomConfig } from "../domain/classroom-config";

export function paintMedia(
  canvas: HTMLCanvasElement,
  config: ClassroomConfig,
  video: HTMLVideoElement | null,
  seconds: number,
  grid = false,
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const w = canvas.width,
    h = canvas.height;
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.translate(config.mapping.flipX ? w : 0, config.mapping.flipY ? h : 0);
  ctx.scale(config.mapping.flipX ? -1 : 1, config.mapping.flipY ? -1 : 1);
  if (video && video.readyState >= 2 && !grid) {
    const chooseScale = config.mapping.fit === "cover" ? Math.max : Math.min;
    const scale = chooseScale(w / video.videoWidth, h / video.videoHeight);
    const dw = video.videoWidth * scale,
      dh = video.videoHeight * scale;
    ctx.drawImage(video, (w - dw) / 2, (h - dh) / 2, dw, dh);
  } else {
    ctx.fillStyle = ["#182839", "#311d35", "#13291f"][config.cueIndex];
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = ["#9cb7ff", "#f3a8cd", "#bceca4"][config.cueIndex];
    ctx.lineWidth = 2;
    for (let x = 0; x <= w; x += w / 12) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y <= h; y += h / 8) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
    ctx.fillStyle = "white";
    ctx.font = `bold ${Math.round(h / 13)}px sans-serif`;
    ctx.fillText(
      grid ? "SCENEFORGE / CALIBRATION" : `CUE ${config.cueIndex + 1} / ${seconds.toFixed(1)}s`,
      w * 0.08,
      h * 0.23,
    );
    ctx.font = `${Math.round(h / 20)}px sans-serif`;
    ctx.fillText("TL", 14, 40);
    ctx.fillText("TR", w - 60, 40);
    ctx.fillText("BL", 14, h - 20);
    ctx.fillText("BR", w - 60, h - 20);
    if (!grid) {
      const radius = h * 0.15;
      ctx.beginPath();
      ctx.arc(w / 2 + Math.sin(seconds) * w * 0.15, h * 0.58, radius, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
  ctx.restore();
}

// Homography maps the source rectangle to a convex output quadrilateral.
export function projectPoint(
  u: number,
  v: number,
  p: readonly (readonly number[])[],
): [number, number] {
  const [p0, p1, p2, p3] = p;
  const dx1 = p1[0] - p2[0],
    dx2 = p3[0] - p2[0],
    dx3 = p0[0] - p1[0] + p2[0] - p3[0];
  const dy1 = p1[1] - p2[1],
    dy2 = p3[1] - p2[1],
    dy3 = p0[1] - p1[1] + p2[1] - p3[1];
  const det = dx1 * dy2 - dx2 * dy1;
  let g = 0,
    h = 0;
  if (Math.abs(dx3) + Math.abs(dy3) > 1e-9 && Math.abs(det) > 1e-9) {
    g = (dx3 * dy2 - dx2 * dy3) / det;
    h = (dx1 * dy3 - dx3 * dy1) / det;
  }
  const a = p1[0] - p0[0] + g * p1[0],
    b = p3[0] - p0[0] + h * p3[0];
  const d = p1[1] - p0[1] + g * p1[1],
    e = p3[1] - p0[1] + h * p3[1];
  const z = g * u + h * v + 1;
  return [(a * u + b * v + p0[0]) / z, (d * u + e * v + p0[1]) / z];
}
function triangle(
  ctx: CanvasRenderingContext2D,
  source: HTMLCanvasElement,
  from: [number, number][],
  to: [number, number][],
) {
  const [s0, s1, s2] = from,
    [d0, d1, d2] = to;
  const det = s0[0] * (s1[1] - s2[1]) + s1[0] * (s2[1] - s0[1]) + s2[0] * (s0[1] - s1[1]);
  const coefficient = (v: number[]) => [
    (v[0] * (s1[1] - s2[1]) + v[1] * (s2[1] - s0[1]) + v[2] * (s0[1] - s1[1])) / det,
    (v[0] * (s2[0] - s1[0]) + v[1] * (s0[0] - s2[0]) + v[2] * (s1[0] - s0[0])) / det,
    (v[0] * (s1[0] * s2[1] - s2[0] * s1[1]) +
      v[1] * (s2[0] * s0[1] - s0[0] * s2[1]) +
      v[2] * (s0[0] * s1[1] - s1[0] * s0[1])) /
      det,
  ];
  const [a, c, e] = coefficient([d0[0], d1[0], d2[0]]),
    [b, d, f] = coefficient([d0[1], d1[1], d2[1]]);
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(...d0);
  ctx.lineTo(...d1);
  ctx.lineTo(...d2);
  ctx.closePath();
  ctx.clip();
  ctx.transform(a, b, c, d, e, f);
  ctx.drawImage(source, 0, 0);
  ctx.restore();
}
export function paintProjection(
  target: HTMLCanvasElement,
  source: HTMLCanvasElement,
  config: ClassroomConfig,
) {
  const ctx = target.getContext("2d");
  if (!ctx) return;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, target.width, target.height);
  if (config.projection.mode === "blackout") return;
  const nx = 16,
    ny = 9;
  for (let y = 0; y < ny; y++)
    for (let x = 0; x < nx; x++) {
      const uv: [number, number][] = [
        [x / nx, y / ny],
        [(x + 1) / nx, y / ny],
        [(x + 1) / nx, (y + 1) / ny],
        [x / nx, (y + 1) / ny],
      ];
      const s: [number, number][] = uv.map(([u, v]) => [u * source.width, v * source.height]);
      const d: [number, number][] = uv.map(([u, v]) => {
        const p = projectPoint(u, v, config.projection.corners);
        return [p[0] * target.width, p[1] * target.height];
      });
      triangle(ctx, source, [s[0], s[1], s[2]], [d[0], d[1], d[2]]);
      triangle(ctx, source, [s[0], s[2], s[3]], [d[0], d[2], d[3]]);
    }
}
