import { OrbitControls } from "@react-three/drei";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Component, type PropsWithChildren, useEffect, useMemo } from "react";
import * as THREE from "three";
import { labPanels } from "../data/spatial-lab";
import type { LabConfig } from "../domain/lab-config";

function Camera({ config }: { config: LabConfig }) {
  const camera = useThree((s) => s.camera);
  const { presetId, viewId } = config;
  const sphere = presetId === "sphere";
  const folded = presetId === "fold";
  const target: [number, number, number] = sphere && viewId !== "overview"
    ? viewId === "side" ? [1, 1.7, 0] : [0, 1.7, -1]
    : folded ? [-2, 2.1, -.8] : [0, presetId === "canopy" ? 3 : 2.3, -1.5];
  const position: [number, number, number] = sphere && viewId !== "overview"
    ? [0, 1.7, 0]
    : viewId === "overview" ? [12, 13, 15]
    : presetId === "hex" ? viewId === "side" ? [2.6, 1.7, 1.5] : [0, 1.7, 0]
    : folded ? viewId === "side" ? [-6.5, 1.7, 1.5] : [-2.7, 1.7, 7]
    : viewId === "side" ? [-6.5, 1.7, 2.5]
    : [0, 1.7, presetId === "arc" ? 3.5 : 7];
  useEffect(() => {
    camera.position.fromArray(position);
    camera.lookAt(...target);
    camera.updateProjectionMatrix();
  }, [camera, position[0], position[1], position[2], target[0], target[1], target[2]]);
  return (
    <OrbitControls
      key={`${presetId}-${viewId}`}
      target={target}
      enablePan={!sphere}
      enableZoom={!sphere || viewId === "overview"}
      minDistance={sphere && viewId !== "overview" ? 0.1 : 2}
      maxDistance={50}
      maxPolarAngle={Math.PI * 0.95}
    />
  );
}
function MediaMaterial({
  source,
  slice = [0, 0, 1, 1],
}: {
  source: HTMLCanvasElement;
  slice?: [number, number, number, number];
}) {
  const texture = useMemo(() => {
    const t = new THREE.CanvasTexture(source);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [source]);
  useEffect(() => {
    texture.offset.set(slice[0], slice[1]);
    texture.repeat.set(slice[2], slice[3]);
  }, [texture, slice[0], slice[1], slice[2], slice[3]]);
  useEffect(() => () => texture.dispose(), [texture]);
  useFrame(() => {
    texture.needsUpdate = true;
  });
  return <meshBasicMaterial map={texture} side={THREE.DoubleSide} toneMapped={false} />;
}
function Arc({ source }: { source: HTMLCanvasElement }) {
  const geometry = useMemo(() => {
    const p: number[] = [],
      uv: number[] = [],
      indices: number[] = [];
    const segments = 96;
    for (let i = 0; i <= segments; i++) {
      const a = -Math.PI / 2 + (i / segments) * Math.PI;
      for (const y of [0, 4.5]) {
        p.push(5 * Math.sin(a), y + 0.4, -5 * Math.cos(a));
        uv.push(i / segments, y / 4.5);
      }
      if (i < segments) {
        const n = i * 2;
        indices.push(n, n + 2, n + 1, n + 1, n + 2, n + 3);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(p, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(indices);
    g.computeVertexNormals();
    return g;
  }, []);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return (
    <mesh geometry={geometry}>
      <MediaMaterial source={source} />
    </mesh>
  );
}
function Screens({ config, source }: { config: LabConfig; source: HTMLCanvasElement }) {
  if (config.presetId === "sphere")
    return (
      <mesh position={[0, 1.7, 0]} scale={[-1, 1, 1]}>
        <sphereGeometry args={[9, 64, 32]} />
        <MediaMaterial source={source} />
      </mesh>
    );
  if (config.presetId === "arc") return <Arc source={source} />;
  return <group>{labPanels(config.presetId).map((panel) => (
    <mesh key={`${config.presetId}-${panel.position.join(",")}`} position={panel.position} rotation={panel.rotation}>
      <planeGeometry args={panel.size} />
      <MediaMaterial source={source} slice={config.distribution === "continuous" ? panel.uv : [0, 0, 1, 1]} />
    </mesh>
  ))}</group>;

}
function Unavailable() {
  return (
    <div className="lab-no-webgl" role="alert">
      3D 画面未能启动。请开启硬件加速或换新版桌面浏览器。内容画布、笔记与参数导出仍可使用。
    </div>
  );
}
class Boundary extends Component<PropsWithChildren, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? <Unavailable /> : this.props.children;
  }
}
export function LabScene({ config, source }: { config: LabConfig; source: HTMLCanvasElement }) {
  return (
    <Boundary>
      <Canvas
        fallback={<Unavailable />}
        dpr={[1, 1.5]}
        camera={{ position: [0, 2.6, 13], fov: 48, near: 0.05, far: 100 }}
        gl={{ antialias: true, preserveDrawingBuffer: true }}
      >
        <color attach="background" args={["#0c121a"]} />
        <ambientLight intensity={1.4} />
        <directionalLight position={[4, 8, 5]} intensity={2.5} />
        <Camera config={config} />
        <Screens config={config} source={source} />
        {config.presetId !== "sphere" && (
          <group>
            <gridHelper args={[28, 28, "#425264", "#26313f"]} position={[0, -0.05, 0]} />
            <mesh position={[0, -0.2, -1]}>
              <boxGeometry args={[12, 0.3, 9]} />
              <meshStandardMaterial color="#1b2632" />
            </mesh>
            <group position={config.presetId === "fold" ? [-1.2, 0, 0.8] : [0, 0, 0]}>
              <mesh position={[0, 0.74, 0]}>
                <cylinderGeometry args={[0.18, 0.22, 1.15, 16]} />
                <meshStandardMaterial color="#f6eed7" />
              </mesh>
              <mesh position={[0, 1.53, 0]}>
                <sphereGeometry args={[0.17, 16, 16]} />
                <meshStandardMaterial color="#f6eed7" />
              </mesh>
            </group>
          </group>
        )}
      </Canvas>
    </Boundary>
  );
}
