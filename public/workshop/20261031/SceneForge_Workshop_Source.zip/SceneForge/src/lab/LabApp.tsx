import { useEffect, useMemo, useRef, useState } from "react";
import { labPresets, labViews, labContentRatio } from "../data/spatial-lab";
import { defaultLabConfig, type LabConfig, parseLabConfig } from "../domain/lab-config";
import { LabScene } from "./LabScene";
import { paintLabMedia } from "./lab-painter";
import "./lab.css";

const KEY = "sceneforge-spatial-lab-v1";
type SourceKind = "pattern" | "file" | "camera" | "screen";
interface RuntimeMedia {
  video: HTMLVideoElement | null;
  stream: MediaStream | null;
  url: string | null;
  kind: SourceKind;
}
interface LabApi {
  getState(): LabConfig;
  setState(input: unknown): LabConfig;
  reset(): LabConfig;
  getMediaState(): {
    kind: SourceKind;
    activeTracks: number;
    width: number;
    height: number;
    readyState: number;
  };
  stopMedia(): void;
}
declare global {
  interface Window {
    sceneForgeLab?: LabApi;
  }
}
function download(data: Blob, name: string) {
  const url = URL.createObjectURL(data),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
const emptyMedia = (): RuntimeMedia => ({ video: null, stream: null, url: null, kind: "pattern" });
function dispose(media: RuntimeMedia) {
  media.video?.pause();
  if (media.video) {
    media.video.srcObject = null;
    media.video.removeAttribute("src");
    media.video.load();
  }
  media.stream?.getTracks().forEach((track) => {
    track.stop();
  });
  if (media.url) URL.revokeObjectURL(media.url);
}
function initialConfig() {
  try {
    const saved = localStorage.getItem(KEY);
    return saved ? parseLabConfig(JSON.parse(saved)) : defaultLabConfig();
  } catch {
    return defaultLabConfig();
  }
}
function captureError(error: unknown) {
  const e = error instanceof Error ? error : new Error(String(error));
  if (["NotAllowedError", "PermissionDeniedError"].includes(e.name))
    return "未授权或已取消。已保留测试图案，可继续练习。";
  if (e.name === "NotFoundError") return "没有可用设备。请改用本地视频或测试图案。";
  if (e.name === "NotReadableError")
    return "设备或窗口无法读取，可能被其他程序占用。已回到测试图案。";
  return `实时输入未连接：${e.message}。可继续使用本地视频或测试图案。`;
}

export function LabApp() {
  const [config, setConfig] = useState<LabConfig>(initialConfig);
  const [message, setMessage] = useState("先选一块屏幕，再带入一段内容。默认图案无需素材和网络。");
  const [sourceKind, setSourceKind] = useState<SourceKind>("pattern");
  const [pending, setPending] = useState(false);
  const [guideOpen, setGuideOpen] = useState(true);
  const configRef = useRef(config);
  configRef.current = config;
  const media = useRef<RuntimeMedia>(emptyMedia());
  const token = useRef(0);
  const mounted = useRef(true);
  const source = useMemo(
    () => Object.assign(document.createElement("canvas"), { width: 960, height: 540 }),
    [],
  );
  const sourcePreview = useRef<HTMLCanvasElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const seconds = useRef(0);
  const preset = labPresets.find((p) => p.id === config.presetId) ?? labPresets[0];

  function commit(input: unknown) {
    const next = parseLabConfig(input);
    configRef.current = next;
    setConfig(next);
    return structuredClone(next);
  }
  function patch(part: Partial<LabConfig>) {
    try {
      commit({ ...configRef.current, ...part });
    } catch (e) {
      setMessage(String(e));
    }
  }
  function stopMedia(note = "已停止输入并释放设备，回到测试图案。") {
    token.current++;
    dispose(media.current);
    media.current = emptyMedia();
    setSourceKind("pattern");
    setPending(false);
    patch({ sourceHint: "内置测试图案" });
    setMessage(note);
  }
  async function startCapture(kind: "camera" | "screen") {
    stopMedia("等待选择或授权。未连接前继续显示测试图案。");
    const id = token.current;
    setPending(true);
    try {
      if (!window.isSecureContext || !navigator.mediaDevices)
        throw new Error("需要 HTTPS 或 localhost 安全页面");
      const stream =
        kind === "camera"
          ? await navigator.mediaDevices.getUserMedia({
              video: { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30 } },
              audio: false,
            })
          : await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      if (!mounted.current || id !== token.current) {
        stream.getTracks().forEach((t) => {
          t.stop();
        });
        return;
      }
      const video = document.createElement("video");
      video.muted = true;
      video.playsInline = true;
      video.srcObject = stream;
      media.current = { video, stream, url: null, kind };
      stream.getVideoTracks().forEach((t) => {
        t.addEventListener(
          "ended",
          () => {
            if (mounted.current && id === token.current)
              stopMedia("共享或设备已结束，已回到测试图案。");
          },
          { once: true },
        );
      });
      await video.play();
      if (!mounted.current || id !== token.current) return;
      setSourceKind(kind);
      setPending(false);
      patch({
        paused: false,
        sourceHint:
          kind === "camera"
            ? "摄像头实时输入（不包含在文件内）"
            : "屏幕分享实时输入（不包含在文件内）",
      });
      setMessage(
        kind === "camera"
          ? "摄像头已连接。画面只在本机使用，未加入网络传输。停止时会释放轨道。"
          : "共享已连接。请在被分享的窗口操作，回来观察它进入空间后的变化。可随时停止共享。",
      );
    } catch (error) {
      if (id === token.current && mounted.current) stopMedia(captureError(error));
    }
  }
  function chooseFile(file?: File) {
    if (!file) return;
    stopMedia("正在读取本地视频。");
    const id = token.current,
      video = document.createElement("video"),
      url = URL.createObjectURL(file);
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.src = url;
    media.current = { video, stream: null, url, kind: "file" };
    video.onerror = () => {
      if (id === token.current && mounted.current)
        stopMedia("视频无法解码，已回到测试图案。请试短 H.264 MP4。");
    };
    video.onloadedmetadata = async () => {
      if (id !== token.current || !mounted.current) return;
      try {
        await video.play();
        if (id !== token.current || !mounted.current) return;
        setSourceKind("file");
        patch({ paused: false, sourceHint: file.name });
        setMessage(`已读取 ${file.name}。视频只在本机播放，导出参数不包含原始文件。`);
      } catch {
        if (id === token.current)
          setMessage("视频已选入，但播放被阻止。请点“播放画面”重试，或切回测试图案。");
      }
    };
  }
  function importConfig(value: unknown) {
    const next = parseLabConfig(value);
    const hint = next.sourceHint;
    stopMedia("");
    commit(next);
    setMessage(
      `参数已恢复。当前使用测试图案。${hint !== "内置测试图案" ? `原输入：${hint}；请重新选择文件或授权实时输入。` : ""}`,
    );
  }
  function snapshot(label: string) {
    const value = structuredClone(configRef.current);
    try {
      localStorage.setItem(`${KEY}-${label}`, JSON.stringify(value));
    } catch {
      /* Export is still available. */
    }
    download(
      new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }),
      `SceneForge-Lab-${label}.json`,
    );
    setMessage(`${label} 参数与笔记已下载。请另存原始素材，实时设备输入不能保存在 JSON 中。`);
  }
  function restore(label: string) {
    try {
      const value = localStorage.getItem(`${KEY}-${label}`);
      if (!value) throw new Error(`尚未保存 ${label}`);
      importConfig(JSON.parse(value));
    } catch (e) {
      setMessage(`未恢复，保留当前状态。${String(e)}`);
    }
  }
  function screenshot() {
    const canvas = stage.current?.querySelector("canvas");
    if (!canvas) {
      setMessage("当前没有可保存的 3D 画面，请先启动视图。");
      return;
    }
    try {
      canvas.toBlob((blob) => {
        if (blob) {
          download(blob, `SceneForge-Lab-${configRef.current.presetId}.png`);
          setMessage("观看图已下载。搭配 V1/V2 参数和修改理由一起分享。");
        }
      });
    } catch {
      setMessage("截图未保存。请用系统截图，并保留参数文件。");
    }
  }
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(config));
    } catch {
      /* Disk export remains available. */
    }
  }, [config]);
  useEffect(() => {
    const video = media.current.video;
    if (!video) return;
    if (config.paused) video.pause();
    else void video.play().catch(() => setMessage("播放未启动。请再次点击播放，或使用测试图案。"));
  }, [config.paused]);
  useEffect(() => {
    let frame = 0,
      last = performance.now();
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    function draw(now: number) {
      const c = configRef.current;
      if (!c.paused && !reduce) seconds.current += Math.min(0.1, (now - last) / 1000);
      last = now;
      const ratio = labContentRatio(c.presetId, c.distribution);
      const height = Math.round(source.width / ratio);
      if (source.height !== height) source.height = height;
      paintLabMedia(source, media.current.video, c, seconds.current);
      const preview = sourcePreview.current;
      if (preview) {
        if (preview.height !== height) preview.height = height;
        preview.getContext("2d")?.drawImage(source, 0, 0, preview.width, preview.height);
      }
      frame = requestAnimationFrame(draw);
    }
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, [source]);
  useEffect(() => {
    mounted.current = true;
    const clean = () => {
      token.current++;
      dispose(media.current);
      media.current = emptyMedia();
    };
    window.addEventListener("pagehide", clean);
    return () => {
      mounted.current = false;
      clean();
      window.removeEventListener("pagehide", clean);
    };
  }, []);
  const methods = useRef({ importConfig, stopMedia });
  methods.current = { importConfig, stopMedia };
  useEffect(() => {
    const api: LabApi = {
      getState: () => structuredClone(configRef.current),
      setState: (value) => {
        const next = parseLabConfig(value);
        methods.current.importConfig(next);
        return structuredClone(configRef.current);
      },
      reset: () => {
        methods.current.importConfig(defaultLabConfig());
        return structuredClone(configRef.current);
      },
      getMediaState: () => ({
        kind: media.current.kind,
        activeTracks:
          media.current.stream?.getTracks().filter((t) => t.readyState === "live").length ?? 0,
        width: media.current.video?.videoWidth ?? 0,
        height: media.current.video?.videoHeight ?? 0,
        readyState: media.current.video?.readyState ?? 0,
      }),
      stopMedia: () => methods.current.stopMedia(),
    };
    window.sceneForgeLab = api;
    return () => {
      if (window.sceneForgeLab === api) delete window.sceneForgeLab;
    };
  }, []);

  return (
    <main className="lab-shell">
      <header className="lab-header">
        <div>
          <p className="lab-eyebrow">SCENEFORGE / SPATIAL SCREEN LAB</p>
          <h1>同一段内容，放进不同空间。</h1>
          <p>先看见变化，再决定怎么改。无需建模基础，所有尺寸均为教学假设。</p>
        </div>
        <nav>
          <button type="button" onClick={() => setGuideOpen((v) => !v)} aria-expanded={guideOpen}>
            第一次使用
          </button>
          <a href="?classroom=1">Cue 与投影课堂版 ↗</a>
        </nav>
      </header>
      {guideOpen && (
        <section className="lab-intro" aria-label="零基础引导">
          <span>三步开始</span>
          <p>
            <b>1</b> 选择一种屏幕。 <b>2</b> 导入短视频，或分享自己程序的窗口。 <b>3</b>{" "}
            换两个观看位置，写下一个问题。
          </p>
          <button type="button" onClick={() => setGuideOpen(false)}>
            开始观察
          </button>
        </section>
      )}
      <div className="lab-body">
        <aside className="lab-controls">
          <section>
            <h2>01 屏幕与观看</h2>
            <div className="lab-preset-list">
              {labPresets.map((p) => (
                <button
                  type="button"
                  key={p.id}
                  aria-pressed={config.presetId === p.id}
                  onClick={() => patch({ presetId: p.id, viewId: "center" })}
                >
                  <span>{p.number}</span>
                  <strong>{p.title}</strong>
                  <small>{p.en}</small>
                </button>
              ))}
            </div>
            <p className="lab-description">{preset.summary}</p>
            <small>{preset.dimension}</small>
            <label>
              观看位置
              <select
                aria-label="观看位置"
                value={config.viewId}
                onChange={(e) => patch({ viewId: e.target.value as LabConfig["viewId"] })}
              >
                {labViews.map((v) => (
                  <option value={v.id} key={v.id}>
                    {v.label}
                  </option>
                ))}
              </select>
            </label>
          </section>
          <section>
            <h2>02 带入你的内容</h2>
            <label>
              选择本地短视频
              <input
                type="file"
                accept="video/*"
                onChange={(e) => {
                  chooseFile(e.target.files?.[0]);
                  e.currentTarget.value = "";
                }}
              />
            </label>
            <div className="lab-actions">
              <button type="button" onClick={() => void startCapture("screen")} disabled={pending}>
                分享程序窗口
              </button>
              <button type="button" onClick={() => void startCapture("camera")} disabled={pending}>
                连接摄像头
              </button>
            </div>
            <div className="lab-actions">
              <button
                type="button"
                onClick={() => stopMedia()}
                disabled={sourceKind === "pattern" && !pending}
              >
                停止输入并释放
              </button>
              <button
                type="button"
                onClick={() => stopMedia("已切回测试图案，原媒体与设备已释放。")}
              >
                使用测试图案
              </button>
            </div>
            <p className="lab-source-kind">
              {pending
                ? "等待选择 / 授权"
                : {
                    pattern: "内置测试图案",
                    file: "本地视频",
                    camera: "摄像头 · 实时",
                    screen: "屏幕分享 · 实时",
                  }[sourceKind]}
            </p>
            <small>
              分享窗口可带入你在其他网页或软件中运行的内容。需主动授权；此处只在本机显示，无跨设备传输。
            </small>
          </section>
          <section>
            <h2>03 内容如何分配</h2>
            <label>
              画面适配
              <select
                aria-label="画面适配"
                value={config.fit}
                onChange={(e) => patch({ fit: e.target.value as LabConfig["fit"] })}
              >
                <option value="contain">完整显示 · 保留全部画面</option>
                <option value="cover">填满裁切 · 检查丢失部分</option>
              </select>
            </label>
            <label>
              多屏内容分配
              <select
                aria-label="多屏内容分配"
                value={config.distribution}
                disabled={!["fold", "floor", "canopy", "hex"].includes(config.presetId)}
                onChange={(e) =>
                  patch({ distribution: e.target.value as LabConfig["distribution"] })
                }
              >
                <option value="continuous">连续跨屏 · 按展开图分配</option>
                <option value="repeat">每屏重复 · 各屏完整播放</option>
              </select>
            </label>
            <label className="lab-check">
              <input
                type="checkbox"
                checked={config.gridOverlay}
                onChange={(e) => patch({ gridOverlay: e.target.checked })}
              />
              叠加内容分区线
            </label>
            <button type="button" onClick={() => patch({ paused: !config.paused })}>
              {config.paused ? "播放画面" : "暂停画面"}
            </button>
            <small>暂停画面不关闭采集设备。使用“停止输入并释放”结束实时输入。</small>
          </section>
          <section>
            <h2>04 留下你的判断</h2>
            <label>
              今天想验证什么？
              <textarea
                rows={2}
                value={config.goal}
                maxLength={500}
                placeholder="例如：我的动作能否跨过两块屏幕？"
                onChange={(e) => patch({ goal: e.target.value })}
              />
            </label>
            <label>
              机位、现象与下一步
              <textarea
                rows={4}
                value={config.notes}
                maxLength={5000}
                placeholder="侧面观看时……我准备只改……"
                onChange={(e) => patch({ notes: e.target.value })}
              />
            </label>
            <div className="lab-actions">
              <button type="button" onClick={() => snapshot("V1")}>
                存 V1
              </button>
              <button type="button" onClick={() => snapshot("V2")}>
                存 V2
              </button>
              <button type="button" onClick={() => restore("V1")}>
                看 V1
              </button>
              <button type="button" onClick={() => restore("V2")}>
                看 V2
              </button>
            </div>
            <button type="button" onClick={screenshot}>
              导出观看图
            </button>
            <label>
              导入实验参数
              <input
                type="file"
                accept="application/json,.json"
                onChange={async (e) => {
                  try {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    if (f.size > 100000) throw new Error("参数文件超过 100KB");
                    importConfig(JSON.parse(await f.text()));
                  } catch (err) {
                    setMessage(`未导入，保留当前状态。${String(err)}`);
                  }
                }}
              />
            </label>
            <small>
              JSON
              保存屏幕、机位与笔记。视频需另存，摄像头和分享窗口需重新授权。浏览器缓存不等于磁盘备份。
            </small>
          </section>
        </aside>
        <section className="lab-workspace">
          <div className="lab-stage" ref={stage}>
            <LabScene config={config} source={source} />
            <div className="lab-stage-label">
              <span>
                {preset.number} / {preset.en}
              </span>
              <strong>{preset.title}</strong>
              <small>
                {config.presetId === "sphere"
                  ? "球内拖动改变方向；总览看结构"
                  : "拖动改变视角 · 屏幕固定 · 中心/侧面为1.7 m人眼高度"}
              </small>
            </div>
          </div>
          <section className="lab-observation">
            <div>
              <p className="lab-eyebrow">OBSERVATION / 观察任务</p>
              <h2>{preset.question}</h2>
              <ol>
                {preset.steps.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ol>
              <p className="lab-takeaway">{preset.takeaway}</p>
            </div>
            <figure>
              <canvas ref={sourcePreview} width={960} height={540} aria-label="当前内容画布" />
              <figcaption>
                内容画布 ·{" "}
                {config.presetId === "sphere"
                  ? "2:1 等距柱状展开"
                  : ["fold", "floor", "canopy", "hex"].includes(config.presetId) && config.distribution === "repeat"
                    ? "每块屏幕重复完整内容"
                    : "沿屏幕展开的同一幅内容"}
              </figcaption>
            </figure>
          </section>
          <p className="lab-status" role="status">
            {message}
          </p>
        </section>
      </div>
    </main>
  );
}
