import type { LabConfig } from "../domain/lab-config";
export function paintLabMedia(
  canvas: HTMLCanvasElement,
  video: HTMLVideoElement | null,
  config: LabConfig,
  seconds: number,
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const w = canvas.width,
    h = canvas.height;
  ctx.fillStyle = "#080d13";
  ctx.fillRect(0, 0, w, h);
  if (video && video.readyState >= 2 && video.videoWidth > 0) {
    const s = (config.fit === "contain" ? Math.min : Math.max)(
      w / video.videoWidth,
      h / video.videoHeight,
    );
    ctx.drawImage(
      video,
      (w - video.videoWidth * s) / 2,
      (h - video.videoHeight * s) / 2,
      video.videoWidth * s,
      video.videoHeight * s,
    );
  } else {
    const colors = ["#ccff73", "#80e2e3", "#c8b0ff", "#ffbe86"];
    for (let i = 0; i < 4; i++) {
      ctx.fillStyle = ["#233821", "#153139", "#2b2544", "#3a2b1b"][i];
      ctx.fillRect((i * w) / 4, 0, w / 4, h);
      ctx.fillStyle = colors[i];
      ctx.font = `600 ${Math.round(h * 0.21)}px sans-serif`;
      ctx.fillText(String(i + 1).padStart(2, "0"), (i * w) / 4 + w * 0.025, h * 0.34);
    }
    ctx.strokeStyle = "#ffffff44";
    ctx.lineWidth = 1;
    for (let x = 0; x <= 16; x++) {
      ctx.beginPath();
      ctx.moveTo((x * w) / 16, 0);
      ctx.lineTo((x * w) / 16, h);
      ctx.stroke();
    }
    for (let y = 0; y <= 8; y++) {
      ctx.beginPath();
      ctx.moveTo(0, (y * h) / 8);
      ctx.lineTo(w, (y * h) / 8);
      ctx.stroke();
    }
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = Math.max(2, h * 0.008);
    const x = ((seconds * 0.09) % 1) * w;
    ctx.beginPath();
    ctx.arc(x, h * 0.65, h * 0.13, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "white";
    ctx.font = `${Math.round(h * 0.055)}px sans-serif`;
    ctx.fillText("ONE CANVAS / FOUR REGIONS", w * 0.025, h * 0.88);
    ctx.fillText("u = 0", w * 0.015, h * 0.98);
    ctx.textAlign = "right";
    ctx.fillText("u = 1", w * 0.985, h * 0.98);
    ctx.textAlign = "left";
  }
  if (config.gridOverlay && video) {
    ctx.strokeStyle = "#ffffff99";
    ctx.lineWidth = 2;
    for (let x = 1; x < 4; x++) {
      ctx.beginPath();
      ctx.moveTo((x * w) / 4, 0);
      ctx.lineTo((x * w) / 4, h);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();
  }
}
