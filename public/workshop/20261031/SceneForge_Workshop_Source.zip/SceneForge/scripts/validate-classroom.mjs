import fs from "node:fs";
import { parseClassroomConfig } from "../src/domain/classroom-config.ts";

try {
  const file = process.argv[2];
  if (!file) throw new Error("Usage: npm run classroom:validate -- path/to/config.json");
  parseClassroomConfig(JSON.parse(fs.readFileSync(file, "utf8")));
  console.log(`VALID SceneForge Classroom v1: ${file}`);
} catch (error) {
  console.error(`INVALID\n${error.message}`);
  process.exitCode = 1;
}
