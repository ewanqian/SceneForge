from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os,webbrowser
os.chdir(Path(__file__).resolve().parent)
print("预览：http://localhost:8766/ ，结束按Ctrl+C")
webbrowser.open("http://localhost:8766/")
ThreadingHTTPServer(("127.0.0.1",8766),SimpleHTTPRequestHandler).serve_forever()
